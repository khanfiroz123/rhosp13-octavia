# Containers based OpenStack deployment

https://docs.openstack.org/tripleo-docs/latest/install/containers_deployment/
